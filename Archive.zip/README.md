# mod_bidslate_media
BidSlate v2 Module for displaying media assets
